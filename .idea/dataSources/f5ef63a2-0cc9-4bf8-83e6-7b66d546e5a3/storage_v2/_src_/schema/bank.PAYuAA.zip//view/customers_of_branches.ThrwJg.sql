create view customers_of_branches as (select `bank`.`account`.`branch_name`     AS `branch_name`,
                                             `bank`.`depositor`.`customer_name` AS `customer_name`
                                      from `bank`.`depositor`
                                               join `bank`.`account`
                                      where (`bank`.`depositor`.`account_number` = `bank`.`account`.`account_number`))
                                     union
                                     (select `bank`.`loan`.`branch_name`       AS `branch_name`,
                                             `bank`.`borrower`.`customer_name` AS `customer_name`
                                      from `bank`.`borrower`
                                               join `bank`.`loan`
                                      where (`bank`.`borrower`.`loan_id` = `bank`.`loan`.`loan_id`));

